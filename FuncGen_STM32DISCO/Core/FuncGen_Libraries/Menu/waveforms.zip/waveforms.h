#pragma once
#include "main.h"
#include "menu.h"
#include "common_waves.h"
#include <vector>
using namespace std;

extern struct wave_param param;

int Get_WaveformLoaded(void);
uint16_t* Waveforms_Menu(uint16_t *array, struct options *option, struct flags *flag);
void Waveforms_CircularMenu(int &wave_selected, struct flags *flag);

class waveforms
{
public:
	int row;
	int waveform_selected;
	int waveform_loaded;
	vector<char*> arr_waveforms;

public:
	waveforms();
    int increment(int n);
};
