#include "waveforms.h"
#include "dutycycle.h"
#include <vector>

using namespace std;
extern waveforms* wave;

int arbwave_screen = 0, duty_screen = 0;
int row = 0, size = 0, op1 = 0, arr_index = 0;

uint16_t* Waveforms_Menu(uint16_t *dac_samples_buffer2, struct options *option, struct flags *flag)
{
    if (option->current == WAVEFORMS) {
        Waveforms_CircularMenu(wave->waveform_selected, flag); // Obtiene el valor de la forma de onda que corresponde de acuerdo a la posici�n del encoder
    }
    switch (wave->waveform_selected) {
    case SQUARE:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
            if (flag->reloadwave == 1) {
                Timer2_Init();
            }
            wave->waveform_loaded = SQUARE;
            Load_Square(&param);
            flag->reloadwave = 0;
        }
        break;
    case RECTANGULAR:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
            duty_screen = 1;
            if (flag->reloadwave == 1) {
                Timer2_Init();
            }
            Load_Rectangular(&param);
            wave->waveform_loaded = RECTANGULAR;
            flag->reloadwave = 0;
        }
        break;
    case SINE:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
        	wave->waveform_loaded = SINE;
            SampleRate_Algorithm(&param);
            dac_samples_buffer2 = Load_Sine(dac_samples_buffer2, &param);
            flag->reloadwave = 0;
        }
        break;
    case HAV:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
        	wave->waveform_loaded = HAV;
            SampleRate_Algorithm(&param);
            Load_Hav(dac_samples_buffer2, &param);
            flag->reloadwave = 0;
        }
        break;
    case TRIANGULAR:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
        	wave->waveform_loaded = TRIANGULAR;
            SampleRate_Algorithm(&param);
            Load_Triangular(dac_samples_buffer2, &param);
            flag->reloadwave = 0;
        }
        break;
    case SAWTOOTH:
        if (wave->waveform_selected != wave->waveform_loaded|| flag->reloadwave == 1) {
        	wave->waveform_loaded = SAWTOOTH;
            SampleRate_Algorithm(&param);
            Load_Sawtooth(dac_samples_buffer2, &param);
            flag->reloadwave = 0;
        }
        break;
    case WHITE:
        if (wave->waveform_selected != wave->waveform_loaded || flag->reloadwave == 1) {
        	wave->waveform_loaded = WHITE;
            SampleRate_Algorithm(&param);
            Load_White(dac_samples_buffer2, &param);
            flag->reloadwave = 0;
        }
        break;
    case ARBITRARY:
    	wave->waveform_loaded = ARBITRARY;
        arbwave_screen = 1;
        break;
    }
    if (wave->waveform_selected !=RECTANGULAR) {
        duty_screen = 0;
    }
    if (wave->waveform_selected !=ARBITRARY) {
        arbwave_screen = 0;
    }
    return dac_samples_buffer2;
}


void Waveforms_CircularMenu(int &ws, struct flags *flag)
	{
	TIM1->ARR = 15; // la flecha tiene 4 lineas para recorrer (4*4-1)
	size = wave->arr_waveforms.size();
	row = TIM1->CNT >> 2; //determino la fila seleccionada (no hay posicion 0 en el display!)

	if(row!=wave->row || flag->recoverview ==1)
    {

		if(flag->recoverview == 1)
		{
			row = wave->row;
			flag->recoverview = 0;
		}
    ws += wave->increment(row); //determino si fue un incremento o un decremento o ninguna

    if((wave->row == 3 && row == 0)|| (wave->row == 0 && row == 3))
		{
			TIM1->CNT = wave->row<<2;
			row = wave->row;
		}

	wave->row = row;

    Print_ArrowRight(row + 1, 11);
    ws = ((ws<0)?(size + ws):(ws))%size; //corrijo el valor para que quede comprendido de 0 a 6
    for(int i = 0; i<4; i++)
		{
			op1 = ws+i-row;
			print_shifted(wave->arr_waveforms.at(op1<0?(size+op1)%size:op1%size),i+1,12);
		}
    }

	char buff[3];
	sprintf(buff, "%d", ws);
	print_shifted(buff, 4, 0);
	}

int Get_WaveformLoaded(void)
	{
	int cw = wave->waveform_selected;
	return cw;
	}

waveforms::waveforms()
{
	this->row = -1;
	this->waveform_loaded = -1;
	this->waveform_selected = -1;
    this->arr_waveforms.push_back("SINE    ");
    this->arr_waveforms.push_back("HAVSINE ");
	this->arr_waveforms.push_back("SQUARE  ");
	this->arr_waveforms.push_back("RECT.   ");
	this->arr_waveforms.push_back("TRIANG. ");
	this->arr_waveforms.push_back("SAWTOOTH");
	this->arr_waveforms.push_back("W.NOISE ");
	this->arr_waveforms.push_back("ARB.WAVE");
}

int waveforms::increment(int n)
{
	int c = n - this->row;
	if(c==0)  return  0;
	if(c==-3) return  1;
	if(c==3)  return -1;
	if(c<0)   return -1;
	if(c>0)   return  1;

    return 0;
}
